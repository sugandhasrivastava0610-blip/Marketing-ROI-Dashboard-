# Marketing ROI Dashboard (SQL + Power BI / Tableau)

An end-to-end marketing analytics project: a relational data model, SQL
queries that compute the core ROI metrics, and a step-by-step guide to
building the dashboard in Power BI or Tableau.

---

## 1. Project structure

```
marketing_roi_dashboard/
├── data/
│   ├── dim_channel.csv              7 marketing channels
│   ├── dim_campaign.csv             14 campaigns, mapped to channels
│   ├── dim_date.csv                 Jan–Dec 2025 calendar table
│   └── fact_daily_performance.csv   3,851 rows: daily spend/clicks/conversions/revenue
├── sql/
│   ├── 01_schema.sql                Table definitions (star schema)
│   └── 02_analysis_queries.sql      Views + KPI queries that power the dashboard
├── generate_data.py                 Script that generated the sample dataset
└── README.md                        This file
```

**Data model (star schema):**

```
dim_channel ──┐
              ├──< fact_daily_performance >──┤
dim_campaign ─┘                              dim_date
```

`fact_daily_performance` has one row per campaign per day, with
`impressions`, `clicks`, `spend`, `leads`, `conversions`, `revenue`.

---

## 2. Load it into a database

Any relational database works. Example for PostgreSQL:

```bash
createdb marketing_roi
psql marketing_roi -f sql/01_schema.sql
psql marketing_roi -c "\copy dim_channel FROM 'data/dim_channel.csv' CSV HEADER"
psql marketing_roi -c "\copy dim_campaign FROM 'data/dim_campaign.csv' CSV HEADER"
psql marketing_roi -c "\copy dim_date FROM 'data/dim_date.csv' CSV HEADER"
psql marketing_roi -c "\copy fact_daily_performance FROM 'data/fact_daily_performance.csv' CSV HEADER"
psql marketing_roi -f sql/02_analysis_queries.sql
```

MySQL/SQL Server work the same way — just swap `\copy` for
`LOAD DATA INFILE` or `BULK INSERT` (both are one-line changes).

No database handy? Power BI and Tableau can both connect **directly to
the CSVs** in `data/` — skip straight to Section 3 or 4.

---

## 3. Core metrics computed in SQL (`02_analysis_queries.sql`)

| Metric | Formula | Business meaning |
|---|---|---|
| **ROAS** (Return on Ad Spend) | `revenue / spend` | $ earned per $ spent |
| **ROI %** | `(revenue − spend) / spend × 100` | % return on investment |
| **CAC** (Customer Acquisition Cost) | `spend / conversions` | cost to acquire one customer |
| **CPC** (Cost per Click) | `spend / clicks` | |
| **CTR** (Click-Through Rate) | `clicks / impressions × 100` | |
| **CVR** (Conversion Rate) | `conversions / clicks × 100` | |
| **Net Profit** | `revenue − spend` | |

The file defines 4 views (`vw_channel_roi`, `vw_campaign_roi`,
`vw_monthly_trend`, `vw_mom_growth`) plus standalone queries for
top/bottom campaigns, weekday-vs-weekend efficiency, and an
overall KPI scorecard. Connect your BI tool to the views directly so
the DAX/calculated-field logic in Sections 4–5 stays simple.

---

## 4. Building it in Power BI

**Connect:**
`Get Data → SQL Server/PostgreSQL database` (or `Get Data → Text/CSV` for
each file in `data/`) → load `dim_channel`, `dim_campaign`, `dim_date`,
`fact_daily_performance`.

**Model view:** Create relationships (drag to connect):
- `dim_channel[channel_id]` → `fact_daily_performance[channel_id]` (1:many)
- `dim_campaign[campaign_id]` → `fact_daily_performance[campaign_id]` (1:many)
- `dim_date[date]` → `fact_daily_performance[date]` (1:many)
- Mark `dim_date` as a **Date Table** (Modeling → Mark as Date Table)

**Key DAX measures** (create in a new "Measures" table):

```DAX
Total Spend       = SUM(fact_daily_performance[spend])
Total Revenue     = SUM(fact_daily_performance[revenue])
Total Conversions = SUM(fact_daily_performance[conversions])
Net Profit        = [Total Revenue] - [Total Spend]

ROAS = DIVIDE([Total Revenue], [Total Spend])

ROI % = DIVIDE([Total Revenue] - [Total Spend], [Total Spend])

CAC = DIVIDE([Total Spend], [Total Conversions])

CTR % = DIVIDE(SUM(fact_daily_performance[clicks]), SUM(fact_daily_performance[impressions]))

CVR % = DIVIDE([Total Conversions], SUM(fact_daily_performance[clicks]))

Revenue MoM % =
VAR CurrMonth = [Total Revenue]
VAR PrevMonth = CALCULATE([Total Revenue], DATEADD(dim_date[date], -1, MONTH))
RETURN DIVIDE(CurrMonth - PrevMonth, PrevMonth)

Spend MoM % =
VAR CurrMonth = [Total Spend]
VAR PrevMonth = CALCULATE([Total Spend], DATEADD(dim_date[date], -1, MONTH))
RETURN DIVIDE(CurrMonth - PrevMonth, PrevMonth)
```

Format `ROAS` as a decimal with "x" suffix, `ROI %` / `CTR %` / `CVR %`
as percentages.

**Suggested page layout:**

1. **Executive Summary** — KPI cards across the top: Total Spend, Total
   Revenue, Net Profit, Blended ROAS, Blended ROI %, CAC. Below: a
   line chart of Spend vs Revenue by month, and a bar chart of ROAS by
   channel.
2. **Channel Performance** — Table/matrix visual using `vw_channel_roi`
   (or the equivalent measures) with columns Spend, Revenue, ROAS,
   ROI %, CAC, CTR %, CVR %, conditionally formatted (data bars) on
   ROI %. Add a scatter chart: Spend (x) vs ROAS (y), bubble size =
   Revenue, one bubble per channel.
3. **Campaign Drill-down** — Table of all campaigns sorted by ROI %
   descending, with a slicer for Channel and Objective. Add a
   top-5/bottom-5 bar chart to spotlight best and worst performers.
4. **Trends** — Monthly Spend vs Revenue combo chart, MoM growth %
   line, and a decomposition tree or ribbon chart of Revenue by
   channel over time.

Add a **Date slicer** and **Channel slicer** synced across all pages
(Format → Edit interactions / sync slicers) so the whole dashboard
filters together.

---

## 5. Building it in Tableau

**Connect:** `Data → Connect → your database` (or connect to each CSV
in `data/` and set up relationships in the Data Source pane by
dragging tables together on `channel_id`, `campaign_id`, and `date`).

**Key calculated fields** (right-click in Data pane → Create Calculated
Field):

```
ROAS
SUM([Revenue]) / SUM([Spend])

ROI %
(SUM([Revenue]) - SUM([Spend])) / SUM([Spend])

CAC
SUM([Spend]) / SUM([Conversions])

CTR %
SUM([Clicks]) / SUM([Impressions])

CVR %
SUM([Conversions]) / SUM([Clicks])

Net Profit
SUM([Revenue]) - SUM([Spend])
```

For month-over-month growth, use a **Table Calculation**: drop
`SUM(Spend)` or `SUM(Revenue)` on a line chart by month, then right
click the pill → *Add Table Calculation* → *Percent Difference From* →
Previous.

**Suggested dashboard layout:**

1. **Overview dashboard** — KPI text/BAN (Big Ass Number) tiles for
   Total Spend, Total Revenue, Net Profit, ROAS, ROI %, CAC across the
   top. Below: a dual-axis line chart (Spend & Revenue by month), and
   a horizontal bar chart of ROAS by Channel (sorted descending, color
   by ROI %).
2. **Channel deep-dive** — A crosstab/text table of the channel KPIs,
   plus a scatter plot (Spend on columns, ROAS on rows, one mark per
   channel, size = Revenue, color = ROI %) to spot the "spend a lot,
   return little" channels.
3. **Campaign performance** — A ranked bar chart of all 14 campaigns
   by ROI %, with a parameter/filter for Channel and Objective, and a
   detail tooltip showing Spend, Revenue, Conversions, CAC.
4. **Trends** — Monthly trend line with a reference line for average
   ROAS, plus a highlight table (heat map) of ROAS by Channel × Month
   to spot seasonality (e.g., the Nov/Dec holiday lift baked into this
   dataset).

Use **Actions** (Dashboard → Actions → Filter) so clicking a channel
bar filters the campaign table below it, and add a Date Range filter
to all sheets.

---

## 6. Talking points this dataset is built to demonstrate

The synthetic data has real, intentional patterns worth calling out
in a portfolio write-up or interview:

- **Organic Search and Email are the ROI leaders** (near-zero paid
  cost, strong ROAS) — classic case for "efficiency vs. scale"
  trade-offs versus paid channels.
- **LinkedIn Ads has the highest CAC** but also the highest AOV/deal
  size (B2B), so blended CAC alone is misleading — worth segmenting
  by objective (Leads vs. Conversions).
- **Nov–Dec holiday campaigns** (`Holiday Sale Blitz`,
  `Holiday Search Surge`) show a deliberate seasonal spend and
  revenue spike — good for a seasonality/trend narrative.
- **Weekday vs weekend performance differs by channel** (B2B/LinkedIn
  drops hard on weekends; Email stays steady) — a good pacing/
  scheduling insight.

Feel free to swap in your own real export from Google Ads, Meta Ads
Manager, LinkedIn Campaign Manager, etc. — as long as the export has
date, channel, campaign, spend, clicks, conversions, and revenue, it
will drop into this same schema and dashboard design.
