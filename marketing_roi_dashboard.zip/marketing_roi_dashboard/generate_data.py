"""
Generates a realistic synthetic marketing performance dataset for the
Marketing ROI Dashboard project (SQL + Power BI / Tableau).

Outputs (CSV, ready to load into a SQL database or directly into
Power BI / Tableau):
  data/dim_channel.csv
  data/dim_campaign.csv
  data/dim_date.csv
  data/fact_daily_performance.csv
"""

import csv
import random
from datetime import date, timedelta

random.seed(42)

START = date(2025, 1, 1)
END = date(2025, 12, 31)

# ---------------------------------------------------------------------
# Dimension: Channels
# ---------------------------------------------------------------------
channels = [
    {"channel_id": 1, "channel_name": "Google Ads",      "channel_type": "Paid Search"},
    {"channel_id": 2, "channel_name": "Meta Ads",         "channel_type": "Paid Social"},
    {"channel_id": 3, "channel_name": "LinkedIn Ads",     "channel_type": "Paid Social"},
    {"channel_id": 4, "channel_name": "Email",            "channel_type": "Owned"},
    {"channel_id": 5, "channel_name": "Affiliate",        "channel_type": "Partner"},
    {"channel_id": 6, "channel_name": "Organic Search",   "channel_type": "Organic"},
    {"channel_id": 7, "channel_name": "Display/Programmatic", "channel_type": "Paid Display"},
]

# Base economics per channel (used to simulate realistic performance)
channel_profile = {
    1: dict(cpc=(1.20, 2.80), ctr=(0.025, 0.055), cvr=(0.03, 0.06), aov=(80, 140), base_impr=(9000, 22000)),
    2: dict(cpc=(0.60, 1.60), ctr=(0.010, 0.030), cvr=(0.015, 0.035), aov=(50, 110), base_impr=(20000, 55000)),
    3: dict(cpc=(3.50, 7.50), ctr=(0.004, 0.012), cvr=(0.02, 0.045), aov=(200, 450), base_impr=(3000, 9000)),
    4: dict(cpc=(0.05, 0.15), ctr=(0.020, 0.045), cvr=(0.04, 0.08), aov=(60, 120), base_impr=(15000, 30000)),
    5: dict(cpc=(0.80, 1.80), ctr=(0.012, 0.028), cvr=(0.02, 0.05), aov=(70, 130), base_impr=(6000, 14000)),
    6: dict(cpc=(0.0, 0.0),   ctr=(0.030, 0.060), cvr=(0.025, 0.05), aov=(65, 125), base_impr=(18000, 40000)),
    7: dict(cpc=(0.30, 0.80), ctr=(0.003, 0.009), cvr=(0.008, 0.02), aov=(55, 100), base_impr=(30000, 70000)),
}

# ---------------------------------------------------------------------
# Dimension: Campaigns (each tied to a channel)
# ---------------------------------------------------------------------
campaign_defs = [
    (101, "Brand Search - Always On",        1, "2025-01-01", "2025-12-31", "Conversions"),
    (102, "Competitor Conquest",              1, "2025-02-01", "2025-11-30", "Conversions"),
    (103, "Prospecting - Lookalike 1%",       2, "2025-01-01", "2025-12-31", "Conversions"),
    (104, "Retargeting - Cart Abandoners",    2, "2025-01-15", "2025-12-31", "Conversions"),
    (105, "Spring Product Launch",            2, "2025-03-01", "2025-04-30", "Awareness"),
    (106, "Decision Maker Outreach",          3, "2025-01-01", "2025-12-31", "Leads"),
    (107, "Q4 Enterprise Push",               3, "2025-09-01", "2025-12-31", "Leads"),
    (108, "Weekly Newsletter",                4, "2025-01-01", "2025-12-31", "Engagement"),
    (109, "Post-Purchase Nurture",            4, "2025-01-01", "2025-12-31", "Retention"),
    (110, "Partner Network - Tier 1",         5, "2025-01-01", "2025-12-31", "Conversions"),
    (111, "Organic Blog & SEO",               6, "2025-01-01", "2025-12-31", "Traffic"),
    (112, "Programmatic Display - Retarget",  7, "2025-01-01", "2025-12-31", "Awareness"),
    (113, "Holiday Sale Blitz",                2, "2025-11-15", "2025-12-31", "Conversions"),
    (114, "Holiday Search Surge",              1, "2025-11-15", "2025-12-31", "Conversions"),
]

with open("data/dim_channel.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["channel_id", "channel_name", "channel_type"])
    w.writeheader()
    w.writerows(channels)

with open("data/dim_campaign.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["campaign_id", "campaign_name", "channel_id", "start_date", "end_date", "objective"])
    for row in campaign_defs:
        w.writerow(row)

# ---------------------------------------------------------------------
# Dimension: Date
# ---------------------------------------------------------------------
def daterange(start, end):
    d = start
    while d <= end:
        yield d
        d += timedelta(days=1)

with open("data/dim_date.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["date", "year", "month", "month_name", "quarter", "day_of_week", "is_weekend"])
    for d in daterange(START, END):
        w.writerow([
            d.isoformat(), d.year, d.month, d.strftime("%B"),
            (d.month - 1) // 3 + 1, d.strftime("%A"),
            1 if d.weekday() >= 5 else 0
        ])

# ---------------------------------------------------------------------
# Fact: Daily performance per campaign
# ---------------------------------------------------------------------
def seasonal_multiplier(d: date) -> float:
    """Adds seasonality: holiday spike in Nov/Dec, summer dip in July."""
    if d.month in (11, 12):
        return 1.35
    if d.month == 7:
        return 0.85
    if d.month in (1, 9):
        return 1.10  # new year / back-to-school bump
    return 1.0

rows = []
for camp_id, camp_name, chan_id, cstart, cend, objective in campaign_defs:
    cstart_d = date.fromisoformat(cstart)
    cend_d = date.fromisoformat(cend)
    prof = channel_profile[chan_id]

    for d in daterange(max(cstart_d, START), min(cend_d, END)):
        mult = seasonal_multiplier(d)
        weekday_mult = 0.75 if d.weekday() >= 5 else 1.0  # lower B2B weekend traffic
        if chan_id in (3,):  # LinkedIn - more B2B, dips harder on weekends
            weekday_mult = 0.4 if d.weekday() >= 5 else 1.0

        impressions = int(random.uniform(*prof["base_impr"]) * mult * weekday_mult)
        ctr = random.uniform(*prof["ctr"])
        clicks = max(0, int(impressions * ctr * random.uniform(0.9, 1.1)))
        cpc = random.uniform(*prof["cpc"])
        spend = round(clicks * cpc, 2) if chan_id != 6 else round(random.uniform(40, 90), 2)  # organic = content cost
        cvr = random.uniform(*prof["cvr"])
        conversions = max(0, int(round(clicks * cvr)))
        # a few leads convert with a lag/higher AOV for B2B leads channel
        aov = random.uniform(*prof["aov"])
        revenue = round(conversions * aov * random.uniform(0.85, 1.2), 2)
        leads = conversions if objective in ("Leads",) else int(conversions * random.uniform(1.1, 1.4))

        rows.append([
            d.isoformat(), camp_id, chan_id, impressions, clicks, round(spend, 2),
            leads, conversions, revenue
        ])

with open("data/fact_daily_performance.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["date", "campaign_id", "channel_id", "impressions", "clicks", "spend",
                "leads", "conversions", "revenue"])
    w.writerows(rows)

print(f"Generated {len(rows)} fact rows across {len(campaign_defs)} campaigns and {len(channels)} channels.")
