-- ============================================================
-- Marketing ROI Dashboard — Analysis Queries
-- These power the Power BI / Tableau visuals (or can be saved
-- as views and connected to directly).
-- ============================================================

-- ------------------------------------------------------------
-- 1. Channel-level ROI summary (headline KPI table)
-- ------------------------------------------------------------
CREATE OR REPLACE VIEW vw_channel_roi AS
SELECT
    c.channel_id,
    c.channel_name,
    c.channel_type,
    SUM(f.impressions)                                   AS impressions,
    SUM(f.clicks)                                         AS clicks,
    SUM(f.spend)                                          AS spend,
    SUM(f.leads)                                          AS leads,
    SUM(f.conversions)                                    AS conversions,
    SUM(f.revenue)                                        AS revenue,
    ROUND(SUM(f.revenue) - SUM(f.spend), 2)                AS net_profit,
    ROUND(SUM(f.revenue) / NULLIF(SUM(f.spend), 0), 2)     AS roas,                 -- Return on Ad Spend
    ROUND((SUM(f.revenue) - SUM(f.spend))
          / NULLIF(SUM(f.spend), 0) * 100, 1)              AS roi_pct,             -- ROI %
    ROUND(SUM(f.spend) / NULLIF(SUM(f.conversions), 0), 2)  AS cac,                 -- Customer Acquisition Cost
    ROUND(SUM(f.spend) / NULLIF(SUM(f.clicks), 0), 2)       AS cpc,                 -- Cost per Click
    ROUND(SUM(f.clicks) * 100.0 / NULLIF(SUM(f.impressions), 0), 2) AS ctr_pct,     -- Click-through rate
    ROUND(SUM(f.conversions) * 100.0 / NULLIF(SUM(f.clicks), 0), 2) AS cvr_pct      -- Conversion rate
FROM fact_daily_performance f
JOIN dim_channel c ON c.channel_id = f.channel_id
GROUP BY c.channel_id, c.channel_name, c.channel_type;


-- ------------------------------------------------------------
-- 2. Campaign-level ROI summary (for ranking / drill-down table)
-- ------------------------------------------------------------
CREATE OR REPLACE VIEW vw_campaign_roi AS
SELECT
    camp.campaign_id,
    camp.campaign_name,
    camp.objective,
    ch.channel_name,
    SUM(f.spend)                                            AS spend,
    SUM(f.revenue)                                           AS revenue,
    SUM(f.conversions)                                       AS conversions,
    ROUND(SUM(f.revenue) / NULLIF(SUM(f.spend), 0), 2)       AS roas,
    ROUND((SUM(f.revenue) - SUM(f.spend))
          / NULLIF(SUM(f.spend), 0) * 100, 1)                AS roi_pct,
    ROUND(SUM(f.spend) / NULLIF(SUM(f.conversions), 0), 2)   AS cac
FROM fact_daily_performance f
JOIN dim_campaign camp ON camp.campaign_id = f.campaign_id
JOIN dim_channel  ch   ON ch.channel_id   = camp.channel_id
GROUP BY camp.campaign_id, camp.campaign_name, camp.objective, ch.channel_name
ORDER BY roi_pct DESC;


-- ------------------------------------------------------------
-- 3. Monthly trend (spend vs revenue vs ROAS over time)
-- ------------------------------------------------------------
CREATE OR REPLACE VIEW vw_monthly_trend AS
SELECT
    d.year,
    d.month,
    d.month_name,
    ch.channel_name,
    SUM(f.spend)   AS spend,
    SUM(f.revenue) AS revenue,
    ROUND(SUM(f.revenue) / NULLIF(SUM(f.spend), 0), 2) AS roas
FROM fact_daily_performance f
JOIN dim_date d     ON d.date = f.date
JOIN dim_channel ch ON ch.channel_id = f.channel_id
GROUP BY d.year, d.month, d.month_name, ch.channel_name
ORDER BY d.year, d.month;


-- ------------------------------------------------------------
-- 4. Month-over-month growth (spend & revenue)
-- ------------------------------------------------------------
CREATE OR REPLACE VIEW vw_mom_growth AS
WITH monthly AS (
    SELECT d.year, d.month,
           SUM(f.spend)   AS spend,
           SUM(f.revenue) AS revenue
    FROM fact_daily_performance f
    JOIN dim_date d ON d.date = f.date
    GROUP BY d.year, d.month
)
SELECT
    year, month, spend, revenue,
    ROUND((spend - LAG(spend) OVER (ORDER BY year, month))
          / NULLIF(LAG(spend) OVER (ORDER BY year, month), 0) * 100, 1)   AS spend_mom_pct,
    ROUND((revenue - LAG(revenue) OVER (ORDER BY year, month))
          / NULLIF(LAG(revenue) OVER (ORDER BY year, month), 0) * 100, 1) AS revenue_mom_pct
FROM monthly
ORDER BY year, month;


-- ------------------------------------------------------------
-- 5. Top / bottom 5 campaigns by ROI
-- ------------------------------------------------------------
-- Top 5
SELECT * FROM vw_campaign_roi ORDER BY roi_pct DESC LIMIT 5;
-- Bottom 5 (candidates to pause or optimize)
SELECT * FROM vw_campaign_roi ORDER BY roi_pct ASC LIMIT 5;


-- ------------------------------------------------------------
-- 6. Weekday vs weekend performance (efficiency check)
-- ------------------------------------------------------------
SELECT
    d.is_weekend,
    ch.channel_name,
    SUM(f.spend)   AS spend,
    SUM(f.revenue) AS revenue,
    ROUND(SUM(f.revenue) / NULLIF(SUM(f.spend), 0), 2) AS roas
FROM fact_daily_performance f
JOIN dim_date d ON d.date = f.date
JOIN dim_channel ch ON ch.channel_id = f.channel_id
GROUP BY d.is_weekend, ch.channel_name
ORDER BY ch.channel_name, d.is_weekend;


-- ------------------------------------------------------------
-- 7. Overall marketing KPI scorecard (single-row summary,
--    great for Power BI card visuals / Tableau KPI tiles)
-- ------------------------------------------------------------
SELECT
    SUM(spend)                                          AS total_spend,
    SUM(revenue)                                          AS total_revenue,
    SUM(revenue) - SUM(spend)                              AS net_profit,
    ROUND(SUM(revenue) / NULLIF(SUM(spend), 0), 2)         AS blended_roas,
    ROUND((SUM(revenue) - SUM(spend)) / NULLIF(SUM(spend), 0) * 100, 1) AS blended_roi_pct,
    SUM(conversions)                                       AS total_conversions,
    ROUND(SUM(spend) / NULLIF(SUM(conversions), 0), 2)     AS blended_cac
FROM fact_daily_performance;
