-- ============================================================
-- Marketing ROI Dashboard — Schema
-- Works on PostgreSQL / MySQL / SQL Server with minor tweaks
-- (flagged inline where a dialect differs)
-- ============================================================

DROP TABLE IF EXISTS fact_daily_performance;
DROP TABLE IF EXISTS dim_campaign;
DROP TABLE IF EXISTS dim_channel;
DROP TABLE IF EXISTS dim_date;

CREATE TABLE dim_channel (
    channel_id      INT PRIMARY KEY,
    channel_name    VARCHAR(50)  NOT NULL,
    channel_type    VARCHAR(30)  NOT NULL
);

CREATE TABLE dim_campaign (
    campaign_id     INT PRIMARY KEY,
    campaign_name   VARCHAR(100) NOT NULL,
    channel_id      INT NOT NULL REFERENCES dim_channel(channel_id),
    start_date      DATE NOT NULL,
    end_date        DATE NOT NULL,
    objective       VARCHAR(30) NOT NULL
);

CREATE TABLE dim_date (
    date            DATE PRIMARY KEY,
    year            INT,
    month           INT,
    month_name      VARCHAR(15),
    quarter         INT,
    day_of_week     VARCHAR(15),
    is_weekend      INT
);

CREATE TABLE fact_daily_performance (
    date            DATE NOT NULL REFERENCES dim_date(date),
    campaign_id     INT  NOT NULL REFERENCES dim_campaign(campaign_id),
    channel_id      INT  NOT NULL REFERENCES dim_channel(channel_id),
    impressions     BIGINT,
    clicks          BIGINT,
    spend           DECIMAL(12,2),
    leads           INT,
    conversions     INT,
    revenue         DECIMAL(12,2)
);

CREATE INDEX idx_fact_date       ON fact_daily_performance(date);
CREATE INDEX idx_fact_campaign   ON fact_daily_performance(campaign_id);
CREATE INDEX idx_fact_channel    ON fact_daily_performance(channel_id);

-- ============================================================
-- Load data (PostgreSQL syntax — for MySQL use LOAD DATA INFILE,
-- for SQL Server use BULK INSERT)
-- ============================================================
-- \copy dim_channel FROM 'data/dim_channel.csv' CSV HEADER;
-- \copy dim_campaign FROM 'data/dim_campaign.csv' CSV HEADER;
-- \copy dim_date FROM 'data/dim_date.csv' CSV HEADER;
-- \copy fact_daily_performance FROM 'data/fact_daily_performance.csv' CSV HEADER;
